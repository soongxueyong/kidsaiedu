# part_1_data.csv
* Apartments in San Francisco vs New York (Part 1) 
* Dataset of homes in San Francisco and New York used in http://www.r2d3.us/visual-intro-to-machine-learning-part-1/
 
# airline_data.csv (Random wreath)
* Features: 
"CRS_DEP_TIME": Flight departure time scheduled in the carriers' Computerized Reservations Systems 
"CRS_ARR_TIME: Flight arrival time scheduled in the carriers' Computerized Reservations Systems
"DISTANCE": Distance between departure & arrival city
"DAY_OF_WEEK": 1 (Monday) to 7 (Sunday)
"origin_lat": Latitude of departure airport
"origin_lng": Longitude of departure airport
"dest_lat": Latitude of arrival airport
"dest_lng": Longitude of arrival airport

Note that origin and destination latitudes & longitudes come from the file *Airport_Codes_mapped_to_Latitude_Longitude_in_the_United_States.csv*